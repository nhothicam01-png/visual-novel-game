ACS.parser=(function(){
 const N=s=>s.toLowerCase().normalize('NFD').replace(/đ/g,'d').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9\s]/g,' ').replace(/\s+/g,' ').trim();
 const has=(n,p)=>(' '+n+' ').includes(' '+p+' '),find=(t,n)=>{let b=null;for(const [k,v] of t)if(has(n,k)&&(!b||k.length>b[0].length))b=[k,v];return b&&b[1]};
 const EMO=[['mim cuoi','Smiling'],['cuoi tuoi','Smiling'],['cuoi','Smiling'],['smile','Smiling'],['cuoi lon','Laughing'],['cuoi pha len','Laughing'],['cuoi to','Laughing'],['bat cuoi','Laughing'],['laugh','Laughing'],
  ['vui ve','Happy'],['vui','Happy'],['hanh phuc','Happy'],['phan khich','Happy'],['hao hung','Happy'],['happy','Happy'],['buon ngu','Sleepy'],['ngap','Sleepy'],['met','Sleepy'],['sleepy','Sleepy'],
  ['buon ba','Sad'],['buon','Sad'],['that vong','Sad'],['sad','Sad'],['tuc gian','Angry'],['gian du','Angry'],['gian','Angry'],['tuc','Angry'],['angry','Angry'],['ngac nhien','Surprised'],['bat ngo','Surprised'],['sung sot','Surprised'],['surprised','Surprised'],
  ['hoang so','Scared'],['so hai','Scared'],['hoang','Scared'],['so','Scared'],['scared','Scared'],['khoc','Crying'],['nuc no','Crying'],['rung rung','Crying'],['crying','Crying'],['boi roi','Confused'],['kho hieu','Confused'],['thac mac','Confused'],['confused','Confused'],
  ['xau ho','Embarrassed'],['nguong','Embarrassed'],['do mat','Embarrassed'],['embarrassed','Embarrassed'],['binh thuong','Neutral'],['than nhien','Neutral'],['neutral','Neutral']];
 const ANIM=[['nhay mua','Dance'],['khieu vu','Dance'],['nhay','Jump'],['lac dau','Shake Head'],['gat dau','Nod'],['quay trai','Turn Left'],['xoay trai','Turn Left'],['quay phai','Turn Right'],['xoay phai','Turn Right'],['cui chao','Bow'],['cui dau','Bow'],['cui nguoi','Bow'],['cui','Bow'],['chao','Bow'],
  ['vay tay','Wave'],['vay','Wave'],['chay','Run'],['ngoi xuong','Sit'],['ngoi','Sit'],['dung day','Stand'],['dung len','Stand'],['dung','Stand'],['nam xuong','Lie Down'],['nam','Lie Down'],['khoc','Cry'],['cuoi','Laugh'],['bat cuoi','Laugh'],['danh','Attack'],['dam','Attack'],['tan cong','Attack'],['di','Walk'],['buoc','Walk'],['tien','Walk']];
 const SHOT=[['can canh','Close Up'],['close up','Close Up'],['trung canh','Medium Shot'],['medium shot','Medium Shot'],['toan canh','Wide Shot'],['wide shot','Wide Shot'],['zoom in','Zoom In'],['phong to','Zoom In'],['zoom out','Zoom Out'],['thu nho','Zoom Out'],['lia','Pan'],['pan','Pan'],['theo','Follow'],['follow','Follow'],['tinh','Static'],['static','Static']];
 const DLG=/^([^:：\[\]()]{1,40}?)\s*(?:\(([^)]*)\))?\s*[:：]\s*(.*)$/u,PAUSE=/^(?:(dung|nghi|doi|cho|pause|wait|im lang|thoi gian)\s*:?\s*)?(\d+(?:[.,]\d+)?)\s*(giay|s|sec|secs|seconds?)?$/;
 const dstrip=s=>s.toLowerCase().normalize('NFD').replace(/đ/g,'d').replace(/[\u0300-\u036f]/g,'').trim();
 function special(inner,sq){const ni=N(inner),pm=dstrip(inner).match(PAUSE);
  if(/^(canh|scene|chuyen canh|dia diem|location|boi canh)(\s|$)/.test(ni)){const sm=inner.match(/^(.*?)\s*[-–—:]\s*(.+)$/u),head=sm?sm[1]:inner;return{k:'scene',num:(head.match(/\d+/)||[])[0],title:sm?sm[2].trim():inner.replace(/^\S+(\s+\d+)?\s*/u,'').trim()}}
  if(/^(camera|cam|goc may|may quay)(\s|$)/.test(ni)||/^(can canh|close up|trung canh|medium shot|toan canh|wide shot|zoom in|zoom out)(\s|$)/.test(ni))return{k:'camera',text:inner};
  if(pm&&(pm[1]||pm[3]))return{k:'pause',seconds:parseFloat(pm[2].replace(',','.'))};return null}
 function classify(t){let m=t.match(/^\[(.*)\]$/);if(m)return special(m[1].trim(),1)||{k:'action',text:m[1].trim()};
  m=t.match(/^\((.*)\)$/);if(m)return special(m[1].trim())||{k:'paren',text:m[1].trim()};
  if(/^(cảnh|scene)\s*\d+/i.test(t)){const s=special(t.replace(/[\s:.-]+$/,''));if(s)return s}
  if(/^(camera|cam)\s*[:：]/i.test(t))return{k:'camera',text:t.replace(/^[^:：]*[:：]/,'')};
  m=t.match(DLG);if(m){const nm=m[1].trim(),w=nm.split(/\s+/);if(w.length<=4&&/^\p{Lu}/u.test(nm)&&!/[.!?,;"]/.test(nm))return{k:'dialogue',name:nm,dir:m[2]||'',text:m[3]}}
  return{k:'plain',text:t}}
 const eventDuration=e=>e.type==='dialogue'?Math.max(1,.4+e.text.length*.065):e.type==='action'?(e.parallel?0:(['Walk','Run'].includes(e.anim)?2.5:e.anim?1.5:1)):e.type==='pause'?e.seconds:e.type==='narration'?Math.max(1.5,e.text.length*.06):0;
 function parse(text,known){known=known||[];const issues=[],P=(line,level,msg)=>issues.push({line,level,msg}),items=[];
  text.replace(/\r/g,'').split('\n').forEach((r,i)=>{const t=r.trim();if(!t||/^(\/\/|#)/.test(t))return;const c=classify(t);c.line=i+1;items.push(c)});
  const names=new Map(),add=n=>{const k=N(n);if(k&&!names.has(k))names.set(k,n.trim())};known.forEach(add);items.forEach(i=>i.k==='dialogue'&&add(i.name));
  const subjects=tx=>{let s=' '+N(tx)+' ';const f=[];for(const [k,d] of [...names].sort((a,b)=>b[0].length-a[0].length)){const i=s.indexOf(' '+k+' ');if(i>=0){f.push([i,d]);s=s.slice(0,i)+' '+'#'.repeat(k.length)+' '+s.slice(i+k.length+2)}}return f.sort((a,b)=>a[0]-b[0]).map(x=>x[1])};
  const scenes=[];let cur=null;const ns=(title,num)=>{cur={id:scenes.length+1,number:+num||scenes.length+1,title:title||'',location:title||'',events:[],characters:[],duration:0};scenes.push(cur)},ev=o=>{if(!cur)ns('');cur.events.push(o)};
  let lastD=null;
  const act=(it,plain)=>{const subs=subjects(it.text),a=find(ANIM,N(it.text));if(plain&&!(subs.length&&a))return ev({type:'narration',line:it.line,text:it.text});
   const tm=it.text.match(/(?:^|\s)(?:đến|tới|về phía|lại gần|vào|ra|lên|xuống)\s+(.+?)\s*$/iu);
   if(!subs.length)P(it.line,'warn','Không xác định được nhân vật trong hành động');if(!a)P(it.line,'warn','Không nhận diện được động tác — sẽ giữ nguyên tư thế');
   ev({type:'action',line:it.line,subject:subs[0]||'',subjects:subs,text:it.text,anim:a||'',target:tm?tm[1]:''})};
  for(const it of items){
   if(it.k==='scene'){if(cur&&!cur.events.length){cur.title=cur.location=it.title;if(it.num)cur.number=+it.num}else ns(it.title,it.num);lastD=null}
   else if(it.k==='camera'){const n=N(it.text);let sh=find(SHOT,n)||'';if(!sh)P(it.line,'warn','Không nhận diện được góc camera');ev({type:'camera',line:it.line,shot:sh,target:subjects(it.text)[0]||''})}
   else if(it.k==='pause')ev({type:'pause',line:it.line,seconds:it.seconds});
   else if(it.k==='dialogue'){const dirs=it.dir?[it.dir]:[],tx=it.text.replace(/\(([^)]*)\)/g,(_,d)=>{dirs.push(d);return ' '}).replace(/\s+/g,' ').trim(),sp=it.name.trim();let emo='',raw='';const acts=[];
    for(const d of dirs){const nd=N(d),e=find(EMO,nd);if(e){if(!emo){emo=e;raw=d.trim()}continue}const a=find(ANIM,nd);if(a){acts.push({a,t:d.trim()});continue}if(d.trim())P(it.line,'warn',`Chỉ dẫn "${d.trim()}" không nhận diện được`)}
    if(tx){lastD={type:'dialogue',line:it.line,speaker:sp,text:tx,expr:emo,rawEmotion:raw};ev(lastD)}
    else if(emo||acts.length){lastD=null;if(emo)ev({type:'expression',line:it.line,subject:sp,expr:emo})}else{P(it.line,'warn',`${sp}: không có lời thoại`)}
    acts.forEach(x=>ev({type:'action',line:it.line,subject:sp,subjects:[sp],text:x.t,anim:x.a,target:'',parallel:true}))}
   else if(it.k==='paren'){const n=N(it.text),e=find(EMO,n),a=find(ANIM,n);
    if(e&&lastD&&!lastD.expr){lastD.expr=e;lastD.rawEmotion=it.text}else if(e)ev({type:'expression',line:it.line,subject:lastD?lastD.speaker:'',expr:e});
    else if(a&&lastD)ev({type:'action',line:it.line,subject:lastD.speaker,subjects:[lastD.speaker],text:it.text,anim:a,target:'',parallel:true});else P(it.line,'warn',`Chỉ dẫn "${it.text}" không nhận diện được`)}
   else if(it.k==='action')act(it,false);else act(it,true)}
  const cnt={};for(const s of scenes){const set=new Set();for(const e of s.events){[e.speaker,e.subject,e.target&&e.type==='camera'?e.target:''].concat(e.subjects||[]).forEach(n=>{if(n){set.add(n);cnt[n]=(cnt[n]||0)+1}})}
   s.characters=[...set];s.duration=+s.events.reduce((a,e)=>a+eventDuration(e),0).toFixed(1)}
  if(!items.length)P(0,'error','Kịch bản trống');else if(!scenes.some(s=>s.events.some(e=>e.type==='dialogue')))P(0,'warn','Chưa có lời thoại nào (định dạng "Tên: lời thoại")');
  return{version:1,scenes,characters:Object.keys(cnt).map(n=>({name:n,mentions:cnt[n]})),issues}}
 return{parse,norm:N,eventDuration,EMO_LIST:[...new Set(EMO.map(x=>x[1]))],SHOTS:[...new Set(SHOT.map(x=>x[1]))]}})();
