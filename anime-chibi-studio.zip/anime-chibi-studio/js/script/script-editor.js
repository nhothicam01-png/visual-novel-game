ACS.scriptEditor=(function(){const S=ACS.state,B=ACS.bus,$=id=>document.getElementById(id),dlg=$('scriptDlg'),ta=$('sText'),gut=$('sGut');
 S.script={text:'',parsed:null,map:{}};try{S.script.text=localStorage.getItem('acs.script')||''}catch(e){}ta.value=S.script.text;
 const SAMPLE=`[Cảnh 1 - Trong phòng]\nLan: (vui vẻ) Chào buổi sáng!\nMinh: (ngạc nhiên) Cậu dậy sớm thế?\n[Lan đi đến cửa sổ]\nLan: Hôm nay chúng ta đi chơi nhé!\n[Camera: cận cảnh Lan]\nMinh: (cười) Ý kiến hay đó!\n[2 giây]\n\n[Cảnh 2 - Công viên]\nLan: (hào hứng) Nhìn kìa, hoa nở đẹp quá!\n[Minh chạy đến chỗ Lan]\nMinh: (mỉm cười) Chờ mình với!`;
 const el=(t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e};
 function lineMarks(){const r=S.script.parsed,m={};if(r)r.issues.forEach(i=>{if(i.line&&m[i.line]!=='e')m[i.line]=i.level==='error'?'e':'w'});
  const n=ta.value.split('\n').length;gut.innerHTML='';for(let i=1;i<=n;i++)gut.appendChild(el('span',m[i]||'',i));gut.scrollTop=ta.scrollTop}
 function go(line){const L=ta.value.split('\n');let a=0;for(let i=0;i<line-1;i++)a+=L[i].length+1;ta.focus();ta.setSelectionRange(a,a+(L[line-1]||'').length);ta.scrollTop=Math.max(0,(line-3)*20)}
 function recalc(){const r=S.script.parsed,cnt={};r.scenes.forEach(s=>{const set=new Set();s.events.forEach(e=>[e.speaker,e.subject,...(e.subjects||[])].forEach(n=>{if(n){set.add(n);cnt[n]=(cnt[n]||0)+1}}));s.characters=[...set];s.duration=+s.events.reduce((a,e)=>a+ACS.parser.eventDuration(e),0).toFixed(1)});
  r.characters=Object.keys(cnt).map(n=>({name:n,mentions:cnt[n]}));ACS.charmap.auto(r.characters.map(c=>c.name));render()}
 function select(opts,val,fn){const s=el('select');opts.forEach(o=>{const p=el('option',null,o[1]);p.value=o[0];s.appendChild(p)});s.value=val;s.onchange=()=>fn(s.value);return s}
 function input(val,w,fn,type){const i=el('input');if(type)i.type=type;i.value=val==null?'':val;i.style.width=w;i.onchange=()=>fn(i.value);return i}
 function row(sc,e){const r=el('div','srow'),tag={dialogue:'Thoại',action:'Hành động',camera:'Camera',pause:'Dừng',narration:'Dẫn',expression:'Biểu cảm'}[e.type],set=k=>v=>{e[k]=v;recalc()};
  const ln=el('button','lnk','L'+e.line);ln.title='Đến dòng '+e.line;ln.onclick=()=>go(e.line);r.append(ln,el('span','stag',tag));
  const EX=[['','(không)'],...ACS.EXPRS.map(x=>[x,x])];
  if(e.type==='dialogue')r.append(input(e.speaker,'80px',set('speaker')),select(EX,e.expr,set('expr')),input(e.text,'100%',set('text')));
  else if(e.type==='action')r.append(input(e.subject,'80px',set('subject')),select([['','(giữ nguyên)'],...Object.keys(ACS.anim.presets).map(x=>[x,x])],e.anim,set('anim')),input(e.target,'110px',set('target')));
  else if(e.type==='camera')r.append(select([['','(không rõ)'],...ACS.parser.SHOTS.map(x=>[x,x])],e.shot,set('shot')),input(e.target,'110px',set('target')));
  else if(e.type==='pause')r.append(input(e.seconds,'70px',v=>{e.seconds=Math.max(0,parseFloat(v)||0);recalc()},'number'));
  else if(e.type==='expression')r.append(input(e.subject,'80px',set('subject')),select(EX,e.expr,set('expr')));
  else r.append(input(e.text,'100%',set('text')));
  const d=el('button','danger','✕');d.onclick=()=>{sc.events=sc.events.filter(x=>x!==e);recalc()};r.append(d);return r}
 function render(){const r=S.script.parsed;lineMarks();const mp=$('sMap'),sc=$('sScenes'),is=$('sIssues');mp.innerHTML=sc.innerHTML=is.innerHTML='';if(!r)return;
  r.characters.forEach(c=>{const li=el('li'),cur=ACS.charmap.get(c.name);li.append(el('span',cur?'':'bad',`${c.name} (${c.mentions})`),select([['','(chưa gán)'],...S.characters.map(x=>[x.id,x.name])],cur?cur.id:'',v=>{ACS.charmap.set(c.name,+v);render()}));mp.appendChild(li)});
  if(!r.characters.length)mp.appendChild(el('li','hint','Chưa phát hiện nhân vật nào'));
  else if(ACS.charmap.unmapped(r.characters.map(c=>c.name)).length)mp.appendChild(el('li','hint','Nhân vật chưa gán: upload nhân vật rồi chọn trong danh sách.'));
  r.scenes.forEach(s=>{const d=el('details');d.open=true;d.appendChild(el('summary',null,`Cảnh ${s.number}${s.title?' — '+s.title:''} · ${s.duration}s · ${s.characters.join(', ')||'-'}`));s.events.forEach(e=>d.appendChild(row(s,e)));sc.appendChild(d)});
  r.issues.forEach(i=>{const li=el('li',i.level==='error'?'e':'w',(i.line?`Dòng ${i.line}: `:'')+i.msg);if(i.line)li.onclick=()=>go(i.line);is.appendChild(li)});if(!r.issues.length)is.appendChild(el('li','hint','Không có vấn đề.'))}
 function parse(){S.script.text=ta.value;try{localStorage.setItem('acs.script',ta.value)}catch(e){}
  const r=ACS.parser.parse(ta.value,S.characters.map(c=>c.name));S.script.parsed=r;ACS.charmap.auto(r.characters.map(c=>c.name));render();
  ACS.toast(`Đã phân tích: ${r.scenes.length} cảnh, ${r.characters.length} nhân vật, ${r.issues.length} vấn đề`,r.issues.some(i=>i.level==='error'));B.emit('script')}
 ta.addEventListener('scroll',()=>gut.scrollTop=ta.scrollTop);ta.addEventListener('input',()=>{S.script.text=ta.value;try{localStorage.setItem('acs.script',ta.value)}catch(e){}lineMarks()});
 ta.addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();parse()}});
 $('sParse').onclick=parse;$('sClose').onclick=()=>{dlg.hidden=true};
 $('sSample').onclick=()=>{if(ta.value.trim()&&!confirm('Thay nội dung hiện tại bằng kịch bản mẫu?'))return;ta.value=SAMPLE;parse()};
 $('sOpen').onclick=()=>$('sFile').click();
 $('sFile').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;if(!/\.txt$/i.test(f.name)&&f.type!=='text/plain')return ACS.toast('Chỉ hỗ trợ file .txt',1);if(f.size>2e6)return ACS.toast('File quá lớn (>2MB)',1);ta.value=await f.text();parse()};
 $('sJson').onclick=()=>{if(!S.script.parsed)return ACS.toast('Hãy phân tích kịch bản trước',1);const u=URL.createObjectURL(new Blob([JSON.stringify({...S.script.parsed,mapping:S.script.map},null,2)],{type:'application/json'})),a=el('a');a.href=u;a.download='script.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)};
 return{open(){dlg.hidden=false;lineMarks();render()},parse}})();
