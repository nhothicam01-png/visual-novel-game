ACS.charmap={
 auto(names){const S=ACS.state,m=S.script.map,N=ACS.parser.norm;names.forEach(n=>{if(m[n]&&S.characters.some(c=>c.id===m[n]))return;delete m[n];const k=N(n);
  const c=S.characters.find(c=>N(c.name)===k)||S.characters.find(c=>{const x=N(c.name);return k&&x&&(x.split(' ').includes(k)||k.split(' ').includes(x))});if(c)m[n]=c.id})},
 get(n){const S=ACS.state;return S.characters.find(c=>c.id===S.script.map[n])||null},
 set(n,id){if(id)ACS.state.script.map[n]=id;else delete ACS.state.script.map[n]},
 unmapped(names){return names.filter(n=>!ACS.charmap.get(n))}};
