ACS.tl=(function(){const S=ACS.state,B=ACS.bus,cv=document.getElementById('tl'),ctx=cv.getContext('2d'),LBL=110,RU=24,ROW=66;let pps=60,sel=null,csel=null,esel=null,lsel=null,drag=null;
 const xOf=t=>LBL+t*pps,tOf=x=>(x-LBL)/pps,snap=t=>Math.max(0,Math.min(S.duration,Math.round(t*S.fps)/S.fps)),clr=()=>{sel=csel=esel=lsel=null},ew=k=>ctx.measureText(k.expr).width+10;
 function size(){cv.width=LBL+S.duration*pps+60;cv.height=RU+Math.max(S.characters.length,3)*ROW+4;draw()}
 function draw(){const has=(s,l)=>s&&S.characters.includes(s.c)&&(!l||s.c[l].includes(s.o));if(sel&&!S.characters.includes(sel.c))sel=null;if(csel&&!has(csel,'clips'))csel=null;if(esel&&!has(esel,'exprKeys'))esel=null;if(lsel&&!has(lsel,'lip'))lsel=null;
  ctx.fillStyle='#1c1f27';ctx.fillRect(0,0,cv.width,cv.height);ctx.font='11px sans-serif';const step=pps>=40?1:5;ctx.fillStyle='#8c93a6';ctx.strokeStyle='#2d323f';
  for(let s=0;s<=S.duration;s+=step){const x=xOf(s);ctx.beginPath();ctx.moveTo(x,RU-6);ctx.lineTo(x,cv.height);ctx.stroke();ctx.fillText(s+'s',x+3,14)}
  S.characters.forEach((c,i)=>{const y=RU+i*ROW;if(c.id===S.selectedId){ctx.fillStyle='#262a38';ctx.fillRect(0,y,cv.width,ROW)}
   ctx.fillStyle='#e4e6ee';ctx.fillText(c.name.slice(0,16),8,y+18);ctx.fillStyle='#8c93a6';
   for(const cl of c.clips||[]){const x0=xOf(cl.start),w=cl.len*pps;ctx.fillStyle=csel&&csel.o===cl?'#ff9d2e':'#8b6cf0';ctx.fillRect(x0,y+26,w,14);ctx.fillStyle='#fff';ctx.save();ctx.beginPath();ctx.rect(x0,y+26,w,14);ctx.clip();ctx.fillText(cl.preset+(cl.loop?' ⟲':''),x0+4,y+37);ctx.restore()}
   for(const k of c.exprKeys||[]){ctx.fillStyle=esel&&esel.o===k?'#ff9d2e':'#2f9e8f';ctx.fillRect(xOf(k.t),y+42,ew(k),12);ctx.fillStyle='#fff';ctx.fillText(k.expr,xOf(k.t)+5,y+52)}
   for(const s of c.lip||[]){const x0=xOf(s.start),w=(s.end-s.start)*pps;ctx.fillStyle=lsel&&lsel.o===s?'#ff9d2e':'#e0558c';ctx.fillRect(x0,y+55,w,10);ctx.fillStyle='#fff';ctx.save();ctx.beginPath();ctx.rect(x0,y+55,w,10);ctx.clip();ctx.fillText(s.text||'',x0+3,y+64);ctx.restore()}
   for(const k of c.keys){const x=xOf(k.t),m=y+13;ctx.beginPath();ctx.moveTo(x,m-7);ctx.lineTo(x+7,m);ctx.lineTo(x,m+7);ctx.lineTo(x-7,m);ctx.closePath();ctx.fillStyle=sel&&sel.k===k?'#ff9d2e':'#6ee7d8';ctx.fill()}});
  ctx.fillStyle='#14161c';ctx.fillRect(0,0,LBL-1,RU);ctx.strokeStyle='#ff4fa0';ctx.beginPath();ctx.moveTo(xOf(S.time),0);ctx.lineTo(xOf(S.time),cv.height);ctx.stroke()}
 const pos=e=>{const r=cv.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}};
 cv.addEventListener('pointerdown',e=>{const p=pos(e);cv.setPointerCapture(e.pointerId);const row=Math.floor((p.y-RU)/ROW),c=S.characters[row];
  if(c&&p.y>=RU&&p.x>=LBL){const ly=p.y-RU-row*ROW;let hit=false;
   if(ly<24){const k=c.keys.find(k=>Math.abs(xOf(k.t)-p.x)<8);if(k){clr();sel={c,k};drag='key';document.getElementById('kEase').value=k.ease;hit=true}}
   else if(ly<41){const o=(c.clips||[]).find(x=>p.x>=xOf(x.start)-2&&p.x<=xOf(x.start+x.len)+2);if(o){clr();csel={c,o};drag={clip:o,rsz:Math.abs(p.x-xOf(o.start+o.len))<7,off:tOf(p.x)-o.start};hit=true}}
   else if(ly<54){const o=(c.exprKeys||[]).find(k=>p.x>=xOf(k.t)&&p.x<=xOf(k.t)+ew(k));if(o){clr();esel={c,o};drag={expr:o};hit=true}}
   else{const o=(c.lip||[]).find(s=>p.x>=xOf(s.start)-2&&p.x<=xOf(s.end)+2);if(o){clr();lsel={c,o};drag={lip:o,rsz:Math.abs(p.x-xOf(o.end))<7,off:tOf(p.x)-o.start,len:o.end-o.start};hit=true}}
   if(hit){ACS.chars.select(c.id);B.emit('clipsel');draw();return}}
  if(c&&p.y>=RU&&p.x<LBL){ACS.chars.select(c.id);return}
  if(p.x>=LBL){clr();drag='scrub';ACS.setTime(snap(tOf(p.x)));B.emit('clipsel')}});
 cv.addEventListener('pointermove',e=>{if(!drag)return;const x=pos(e).x,t=snap(tOf(x));
  if(drag==='scrub')return ACS.setTime(t);if(drag==='key'){if(sel){sel.k.t=t;sel.c.keys.sort((a,b)=>a.t-b.t)}}
  else if(drag.clip){if(drag.rsz)drag.clip.len=Math.max(.1,t-drag.clip.start);else drag.clip.start=snap(tOf(x)-drag.off)}
  else if(drag.expr){drag.expr.t=t;esel.c.exprKeys.sort((a,b)=>a.t-b.t)}
  else if(drag.lip){const s=drag.lip;if(drag.rsz){s.end=Math.max(s.start+.1,t);if(!s.audio)ACS.lip.build(s)}else{s.start=snap(tOf(x)-drag.off);s.end=s.start+drag.len}}
  B.emit('keys')});
 cv.addEventListener('pointerup',()=>drag=null);
 ['time','chars','select','keys'].forEach(e=>B.on(e,draw));
 const ch=()=>{const c=S.selected;if(!c)ACS.toast('Chọn một nhân vật trước',1);return c},none=()=>ACS.toast('Chưa chọn mục nào để xóa',1);
 return{size,draw,setZoom(v){pps=v;size()},get sel(){return sel},get csel(){return csel},get esel(){return esel},get lsel(){return lsel},
  add(){const c=ch();if(!c)return;clr();sel={c,k:ACS.keyframe.set(c,S.time,ACS.keyframe.snapshot(c))};B.emit('keys')},
  dup(){if(!sel)return ACS.toast('Chọn một keyframe trước',1);const k=ACS.keyframe.set(sel.c,S.time,{...sel.k.props},sel.k.ease);sel={c:sel.c,k};B.emit('keys')},
  del(){if(!sel)return ACS.toast('Chọn một keyframe trước',1);ACS.keyframe.remove(sel.c,sel.k);sel=null;B.emit('keys')},
  ease(v){if(sel){sel.k.ease=v;B.emit('keys')}},
  addClip(n){const c=ch(),p=ACS.anim.presets[n];if(!c||!p)return;(c.clips=c.clips||[]);const o={preset:n,start:S.time,len:p.dur,loop:p.loop,speed:1,fade:.15};c.clips.push(o);clr();csel={c,o};B.emit('clipsel');B.emit('keys')},
  delClip(){if(!csel)return none();csel.c.clips=csel.c.clips.filter(x=>x!==csel.o);csel=null;B.emit('clipsel');B.emit('keys')},
  setClip(k,v){if(csel){csel.o[k]=v;B.emit('keys')}},
  addExpr(n){const c=ch();if(!c)return;c.exprKeys=c.exprKeys||[];let o=c.exprKeys.find(k=>Math.abs(k.t-S.time)<1e-6);if(o)o.expr=n;else{o={t:S.time,expr:n};c.exprKeys.push(o)}c.exprKeys.sort((a,b)=>a.t-b.t);clr();esel={c,o};B.emit('clipsel');B.emit('keys')},
  delExpr(){if(!esel)return none();esel.c.exprKeys=esel.c.exprKeys.filter(x=>x!==esel.o);esel=null;B.emit('clipsel');B.emit('keys')},
  addLip(){const c=ch();if(!c)return;(c.lip=c.lip||[]);const o={start:S.time,end:S.time+2,text:'Xin chào!',expr:''};o.visStr=ACS.lip.textToVis(o.text);ACS.lip.build(o);c.lip.push(o);clr();lsel={c,o};B.emit('clipsel');B.emit('keys')},
  delLip(){if(!lsel)return none();lsel.c.lip=lsel.c.lip.filter(x=>x!==lsel.o);lsel=null;B.emit('clipsel');B.emit('keys')},
  async lipAudio(f){if(!lsel)return ACS.toast('Chọn một đoạn lời thoại trước',1);const o=lsel.o;try{const r=await ACS.lip.analyze(f);o.audio={name:f.name,blob:f,dur:r.dur};o.voiced=r.voiced;o.end=o.start+r.dur;ACS.lip.build(o);B.emit('clipsel');B.emit('keys');ACS.toast('Đã gắn audio: '+r.voiced.length+' đoạn có tiếng')}catch(err){ACS.toast(err.message,1)}},
  lipEdit(k,v){if(!lsel)return;const o=lsel.o;o[k]=v;if(k==='text')o.visStr=ACS.lip.textToVis(v);if(k==='start'||k==='end'){if(o.end<o.start+.1)o.end=o.start+.1}ACS.lip.build(o);B.emit('clipsel');B.emit('keys')}}})();
