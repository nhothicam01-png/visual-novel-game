window.ACS=window.ACS||{};
ACS.bus={h:{},on(e,f){(this.h[e]||(this.h[e]=[])).push(f)},emit(e,d){(this.h[e]||[]).forEach(f=>f(d))}};
