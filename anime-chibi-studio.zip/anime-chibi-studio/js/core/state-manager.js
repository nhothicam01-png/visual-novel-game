ACS.state={characters:[],selectedId:null,time:0,duration:10,fps:30,playing:false,nextId:1,
 get selected(){return this.characters.find(c=>c.id===this.selectedId)||null}};
