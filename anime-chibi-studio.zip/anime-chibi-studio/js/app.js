(function(){const S=ACS.state,B=ACS.bus,$=id=>document.getElementById(id);
 ACS.toast=(m,err)=>{const d=document.createElement('div');d.className='toast'+(err?' err':'');d.textContent=m;document.body.appendChild(d);setTimeout(()=>d.remove(),3500)};
 ACS.setTime=t=>{S.time=Math.max(0,Math.min(S.duration,t));S.characters.forEach(c=>{const e=ACS.keyframe.evaluate(c,S.time);if(e)ACS.keyframe.apply(c,e);ACS.anim.apply(c,S.time);ACS.face.apply(c,S.time)});B.emit('time')};
 // Upload
 $('btnUpload').onclick=()=>$('file').click();
 $('file').onchange=async e=>{for(const f of e.target.files){try{await ACS.chars.add(f)}catch(err){ACS.toast(err.message,1)}}e.target.value=''};
 $('btnScript').onclick=()=>ACS.scriptEditor.open();$('btnRig').onclick=()=>ACS.rigEditor.open();$('btnDup').onclick=()=>ACS.chars.duplicate();$('btnRen').onclick=()=>ACS.chars.rename();$('btnDel').onclick=()=>ACS.chars.remove();
 $('layUp').onclick=()=>ACS.chars.moveLayer(1);$('layDn').onclick=()=>ACS.chars.moveLayer(-1);
 // Properties
 const fill=()=>{const c=S.selected;document.querySelectorAll('[data-p]').forEach(el=>{el.disabled=!c;if(!c)return;const v=c.props[el.dataset.p];
  if(el.type==='checkbox')el.checked=!!v;else if(document.activeElement!==el)el.value=Math.round(v*100)/100})};
 document.querySelectorAll('[data-p]').forEach(el=>el.addEventListener('input',()=>{const c=S.selected;if(!c)return;
  c.props[el.dataset.p]=el.type==='checkbox'?el.checked:(parseFloat(el.value)||0);B.emit('edit',c)}));
 B.on('edit',c=>{if($('autokey').checked){const p=c.props;ACS.keyframe.set(c,S.time,ACS.keyframe.snapshot(c));B.emit('keys')}});
 ['time','select','edit','chars'].forEach(e=>B.on(e,fill));
 // Keyframes
 $('kAdd').onclick=()=>ACS.tl.add();$('kDup').onclick=()=>ACS.tl.dup();$('kDel').onclick=()=>ACS.tl.del();$('kEase').onchange=e=>ACS.tl.ease(e.target.value);
 // Transport
 let last=0;const tick=ts=>{if(!S.playing)return;const t=S.time+(ts-last)/1000;last=ts;if(t>=S.duration){ACS.setTime(S.duration);stop();return}ACS.setTime(t);requestAnimationFrame(tick)};
 function stop(){S.playing=false;$('play').textContent='▶'}
 function play(){if(S.playing)return stop();if(S.time>=S.duration)ACS.setTime(0);S.playing=true;$('play').textContent='⏸';last=performance.now();requestAnimationFrame(tick)}
 $('play').onclick=play;B.on('time',()=>$('timeLbl').textContent=S.time.toFixed(2)+'s');
 $('dur').onchange=e=>{S.duration=Math.max(1,Math.min(600,+e.target.value||10));e.target.value=S.duration;ACS.setTime(S.time);ACS.tl.size()};
 $('fps').onchange=e=>S.fps=+e.target.value;$('safe').onchange=e=>ACS.editor.setSafe(e.target.checked);$('zoom').oninput=e=>ACS.tl.setZoom(+e.target.value);
 document.addEventListener('keydown',e=>{if(/INPUT|SELECT|TEXTAREA/.test(e.target.tagName))return;
  if(e.code==='Space'){e.preventDefault();play()}else if(e.key==='Delete'){if(ACS.tl.csel)ACS.tl.delClip();else if(ACS.tl.esel)ACS.tl.delExpr();else if(ACS.tl.lsel)ACS.tl.delLip();else if(ACS.tl.sel)ACS.tl.del()}});
 const fp=()=>{const s=$('aPreset'),v=s.value;s.innerHTML='';Object.keys(ACS.anim.presets).forEach(n=>{const o=document.createElement('option');o.textContent=n;s.appendChild(o)});if(v)s.value=v};fp();
 $('aAdd').onclick=()=>ACS.tl.addClip($('aPreset').value);$('aDel').onclick=()=>ACS.tl.delClip();
 const clipUI=()=>{lipUI();const s=ACS.tl.csel,cl=s&&s.o;['cLen','cSpd','cFade','cLoop'].forEach(i=>$(i).disabled=!cl);if(!cl)return;$('cLen').value=cl.len;$('cSpd').value=cl.speed;$('cFade').value=cl.fade;$('cLoop').checked=cl.loop};
 [['cLen','len',.1],['cSpd','speed',.1],['cFade','fade',0]].forEach(([i,k,mn])=>$(i).onchange=e=>ACS.tl.setClip(k,Math.max(mn,parseFloat(e.target.value)||1)));
 $('cLoop').onchange=e=>ACS.tl.setClip('loop',e.target.checked);B.on('clipsel',clipUI);B.on('keys',()=>{clipUI();ACS.setTime(S.time)});
 $('aMake').onclick=()=>{const c=S.selected;if(!c)return ACS.toast('Chọn nhân vật trước',1);const n=prompt('Tên preset');if(!n||!n.trim())return;
  try{ACS.anim.fromKeys(c,n.trim(),confirm('Preset lặp lại?'));fp();$('aPreset').value=n.trim();ACS.toast('Đã lưu preset '+n.trim())}catch(err){ACS.toast(err.message,1)}};
 $('aRm').onclick=()=>{const p=ACS.anim.presets[$('aPreset').value];if(!p||!p.user)return ACS.toast('Chỉ xóa được preset do bạn tạo',1);delete ACS.anim.presets[p.name];ACS.anim.save();fp()};
 const fillOpts=(id,list)=>{list.forEach(n=>{const o=document.createElement('option');o.value=n[0];o.textContent=n[1];$(id).appendChild(o)})};
 fillOpts('fExpr',ACS.EXPRS.map(n=>[n,n]));fillOpts('lExpr',[['','(giữ nguyên)'],...ACS.EXPRS.map(n=>[n,n])]);
 function lipUI(){const s=ACS.tl.lsel,o=s&&s.o;['lText','lVis','lExpr','lStart','lEnd'].forEach(i=>$(i).disabled=!o);if(!o)return;
  const set=(i,v)=>{if(document.activeElement!==$(i))$(i).value=v};set('lText',o.text);set('lVis',o.visStr);$('lExpr').value=o.expr||'';set('lStart',o.start);set('lEnd',+o.end.toFixed(2))}
 $('fSet').onclick=()=>ACS.tl.addExpr($('fExpr').value);$('fDel').onclick=()=>ACS.tl.delExpr();$('fEdit').onclick=()=>ACS.faceEditor.open();
 $('lAdd').onclick=()=>ACS.tl.addLip();$('lDel').onclick=()=>ACS.tl.delLip();$('lAudio').onclick=()=>$('lFile').click();
 $('lFile').onchange=e=>{const f=e.target.files[0];e.target.value='';if(f)ACS.tl.lipAudio(f)};
 $('lText').oninput=e=>ACS.tl.lipEdit('text',e.target.value);$('lVis').onchange=e=>ACS.tl.lipEdit('visStr',e.target.value);$('lExpr').onchange=e=>ACS.tl.lipEdit('expr',e.target.value);
 $('lStart').onchange=e=>ACS.tl.lipEdit('start',Math.max(0,+e.target.value||0));$('lEnd').onchange=e=>ACS.tl.lipEdit('end',+e.target.value||0);
 ACS.tl.size();fill();clipUI();
})();
