ACS.EXPRS=['Neutral','Happy','Sad','Angry','Surprised','Scared','Crying','Laughing','Confused','Sleepy','Embarrassed','Smiling'];
ACS.VISEMES=['A','E','I','O','U','M','F','L','Rest'];
ACS.face={apply(c,t){const f=c.face=c.face||{};let ex='Neutral';for(const k of c.exprKeys||[])if(k.t<=t)ex=k.expr;f.speaking=false;f.viseme='Rest';
 for(const s of c.lip||[])if(t>=s.start&&t<s.end){f.speaking=true;if(s.expr)ex=s.expr;for(const v of s.vis||[])if(s.start+v.t<=t)f.viseme=v.v}f.expr=ex}};
ACS.faceEditor=(function(){const S=ACS.state,$=id=>document.getElementById(id),dlg=$('faceDlg'),cv=$('fcCv'),ctx=cv.getContext('2d'),rig=ACS.rig;
 let c=null,slot='eyes',key='Neutral',pend='open',target=null,exPrev='Neutral';
 const piece=()=>c.rig.pieces.find(p=>p.slot===slot),keys=()=>slot==='eyes'?ACS.EXPRS:[...ACS.EXPRS,...ACS.VISEMES],isV=k=>ACS.VISEMES.includes(k);
 function show(){c.face=isV(key)?{expr:exPrev,viseme:key,speaking:true}:(exPrev=key,{expr:key,viseme:'Rest',speaking:false})}
 function ui(){const p=piece(),ul=$('fTex');ul.innerHTML='';$('fMode').disabled=slot!=='mouth';$('fMode').value=p?(p.mouthMode||'open'):pend;
  keys().forEach(k=>{const li=document.createElement('li'),ix=p&&p.tex[k],n=document.createElement('span');li.className=k===key?'on':'';n.textContent=k;n.style.flex=1;li.appendChild(n);
   if(ix!=null&&c.rig.images[ix]){const im=document.createElement('img');im.src=c.rig.images[ix].url;im.alt='';li.appendChild(im)}
   const up=document.createElement('button'),x=document.createElement('button');up.textContent='Tải';x.textContent='✕';x.disabled=ix==null;
   up.onclick=e=>{e.stopPropagation();target=k;$('fFile').click()};x.onclick=e=>{e.stopPropagation();clear(k)};li.append(up,x);li.onclick=()=>{key=k;show();ui()};ul.appendChild(li)});
  const o=p&&!isV(key)&&p.off&&p.off[key]||{x:0,y:0};['fOx','fOy'].forEach(i=>$(i).disabled=!p||isV(key));$('fOx').value=o.x;$('fOy').value=o.y}
 function clear(k){const p=piece(),r=c.rig,ix=p.tex[k];delete p.tex[k];const rest=Object.values(p.tex);
  if(!rest.length)r.pieces=r.pieces.filter(q=>q!==p);else if(p.img===ix)p.img=rest[0];rig.gc(c);ui()}
 $('fFile').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;
  try{const l=await ACS.loader.load(f),r=c.rig;r.images.push({bmp:l.bmp,blob:l.blob,url:l.url});const ix=r.images.length-1;let p=piece();
   if(!p){const hd=r.bones.find(b=>b.type==='Head');p={slot,tex:{},off:{},mouthMode:pend,img:ix,sx:0,sy:0,sw:l.bmp.width,sh:l.bmp.height,x:-l.bmp.width/2,y:-l.bmp.height/2,bone:hd?hd.id:null,cut:false,name:slot==='eyes'?'Mắt':'Miệng'};r.pieces.push(p)}
   const old=p.tex[target];p.tex[target]=ix;if(old!=null)rig.gc(c);key=target;show();ui()}catch(err){ACS.toast(err.message,1)}};
 document.querySelectorAll('[name=fslot]').forEach(r=>r.onchange=()=>{slot=r.value;key='Neutral';show();ui()});
 $('fMode').onchange=e=>{const p=piece();if(p)p.mouthMode=e.target.value;else pend=e.target.value};
 ['fOx','fOy'].forEach(i=>$(i).onchange=()=>{const p=piece();if(!p||isV(key))return;p.off[key]={x:+$('fOx').value||0,y:+$('fOy').value||0}});
 $('fClose').onclick=()=>{dlg.hidden=true;ACS.setTime(S.time)};
 function draw(){if(dlg.hidden)return;ctx.fillStyle='#2a2d38';ctx.fillRect(0,0,cv.width,cv.height);const s=Math.min(1,(cv.height-20)/c.bmp.height,(cv.width-20)/c.bmp.width);
  ctx.save();ctx.translate(cv.width/2,cv.height/2);ctx.scale(s,s);rig.noAnim=true;rig.draw(ctx,c);rig.noAnim=false;ctx.restore();requestAnimationFrame(draw)}
 return{open(){c=S.selected;if(!c)return ACS.toast('Chọn một nhân vật trước',1);rig.ensure(c);slot='eyes';key='Neutral';exPrev='Neutral';document.querySelector('[name=fslot][value=eyes]').checked=true;show();dlg.hidden=false;ui();draw()}}})();
