ACS.loader={ALLOWED:['image/png','image/jpeg','image/webp'],MAX:15*1024*1024,
 async load(f){if(!this.ALLOWED.includes(f.type))throw new Error(`"${f.name}": chỉ hỗ trợ PNG, JPG, WebP`);
  if(f.size>this.MAX)throw new Error(`"${f.name}" vượt quá 15MB`);
  let bmp;try{bmp=await createImageBitmap(f)}catch(e){throw new Error(`Không đọc được ảnh "${f.name}"`)}
  return{bmp,blob:f,url:URL.createObjectURL(f)}}};
