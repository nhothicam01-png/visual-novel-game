ACS.chars=(function(){const S=ACS.state,B=ACS.bus,ul=document.getElementById('charList');
 function make(r,name,props,keys){return{id:S.nextId++,name,url:r.url,blob:r.blob,bmp:r.bmp,props,keys}}
 const api={
  async add(f){const r=await ACS.loader.load(f);
   const c=make(r,f.name.replace(/\.[^.]+$/,''),{x:640,y:360,scale:Math.min(1,450/r.bmp.height),rotation:0,opacity:1,flipH:false,flipV:false},[]);
   S.characters.push(c);api.select(c.id);B.emit('chars')},
  select(id){S.selectedId=id;B.emit('select')},
  remove(){const c=S.selected;if(!c)return;URL.revokeObjectURL(c.url);c.bmp.close();ACS.rig.dispose(c);
   S.characters=S.characters.filter(x=>x!==c);S.selectedId=S.characters.length?S.characters[S.characters.length-1].id:null;B.emit('chars');B.emit('select')},
  async duplicate(){const c=S.selected;if(!c)return;const bmp=await createImageBitmap(c.blob);
   const n=make({bmp,blob:c.blob,url:URL.createObjectURL(c.blob)},c.name+' copy',{...c.props,x:c.props.x+40,y:c.props.y+40},JSON.parse(JSON.stringify(c.keys)));
   await ACS.rig.clone(c,n);S.characters.push(n);api.select(n.id);B.emit('chars')},
  rename(){const c=S.selected;if(!c)return;const n=prompt('Tên nhân vật',c.name);if(n&&n.trim()){c.name=n.trim();B.emit('chars')}},
  moveLayer(d){const i=S.characters.indexOf(S.selected),j=i+d;if(i<0||j<0||j>=S.characters.length)return;
   [S.characters[i],S.characters[j]]=[S.characters[j],S.characters[i]];B.emit('chars')}};
 function render(){ul.innerHTML='';[...S.characters].reverse().forEach(c=>{const li=document.createElement('li');li.className=c.id===S.selectedId?'on':'';
  const im=document.createElement('img');im.src=c.url;im.alt='';const s=document.createElement('span');s.textContent=c.name;li.append(im,s);li.onclick=()=>api.select(c.id);ul.appendChild(li)})}
 B.on('chars',render);B.on('select',render);return api})();
