ACS.rig=(function(){const api={rest:false,
 ensure(c){if(c.rig)return c.rig;const w=c.bmp.width,h=c.bmp.height;
  return c.rig={bones:[],nid:1,images:[{bmp:c.bmp,blob:c.blob,url:c.url}],pieces:[{img:0,sx:0,sy:0,sw:w,sh:h,x:-w/2,y:-h/2,bone:null,cut:false,base:true,name:'Ảnh gốc'}]}},
 bone(c,id){return id==null?null:c.rig.bones.find(b=>b.id===id)||null},
 world(c,b){const ch=[];for(let x=b;x&&ch.length<64;x=api.bone(c,x.parent))ch.unshift(x);
  let m=new DOMMatrix(),p=null;for(const x of ch){m=m.translate(x.x-(p?p.x:0),x.y-(p?p.y:0));if(!api.rest)m=m.rotate(x.rot+(api.noAnim?0:(x.arot||0)));p=x}return m},
 draw(ctx,c){const r=api.ensure(c);for(const p0 of r.pieces){const p=p0.slot?api.slotPiece(c,p0):p0;if(!p)continue;const im=r.images[p.img];if(!im)continue;
  if(p.base){const hs=r.pieces.filter(q=>q.cut&&q.img===p.img);
   if(hs.length){ctx.save();ctx.beginPath();ctx.rect(p.x,p.y,p.sw,p.sh);hs.forEach(q=>ctx.rect(q.x,q.y,q.sw,q.sh));ctx.clip('evenodd');ctx.drawImage(im.bmp,p.x,p.y);ctx.restore()}
   else ctx.drawImage(im.bmp,p.x,p.y);continue}
  const b=api.bone(c,p.bone);ctx.save();
  if(b){const m=api.world(c,b);ctx.transform(m.a,m.b,m.c,m.d,m.e,m.f);ctx.drawImage(im.bmp,p.sx,p.sy,p.sw,p.sh,p.x-b.x,p.y-b.y,p.sw,p.sh)}
  else ctx.drawImage(im.bmp,p.sx,p.sy,p.sw,p.sh,p.x,p.y,p.sw,p.sh);ctx.restore()}},
 slotPiece(c,p){const r=c.rig,f=c.face||{},ex=f.expr||'Neutral',mo=p.slot==='mouth'&&p.mouthMode!=='fixed';let ix=p.img;
  for(const k of mo?(f.speaking?[f.viseme,ex,'Neutral']:[ex,'Rest','Neutral']):[ex,'Neutral'])if(p.tex[k]!=null&&r.images[p.tex[k]]){ix=p.tex[k];break}
  const im=r.images[ix];if(!im)return null;const o=(p.off&&p.off[ex])||{x:0,y:0},w=im.bmp.width,h=im.bmp.height;
  return{img:ix,sx:0,sy:0,sw:w,sh:h,x:p.x+p.sw/2+o.x-w/2,y:p.y+p.sh/2+o.y-h/2,bone:p.bone}},
 gc(c){const r=c.rig,u=new Set([0]);r.pieces.forEach(p=>{u.add(p.img);if(p.tex)Object.values(p.tex).forEach(i=>u.add(i))});r.images.forEach((im,i)=>{if(im&&!u.has(i)){URL.revokeObjectURL(im.url);im.bmp.close();r.images[i]=null}})},
 dispose(c){if(!c.rig)return;c.rig.images.forEach((im,i)=>{if(im&&i>0){URL.revokeObjectURL(im.url);im.bmp.close()}})},
 async clone(c,n){if(!c.rig)return;const r=c.rig,nr=api.ensure(n);nr.bones=JSON.parse(JSON.stringify(r.bones));nr.nid=r.nid;nr.pieces=JSON.parse(JSON.stringify(r.pieces));
  nr.images=[nr.images[0]];for(let i=1;i<r.images.length;i++){const im=r.images[i];nr.images[i]=im?{blob:im.blob,url:URL.createObjectURL(im.blob),bmp:await createImageBitmap(im.blob)}:null}}};
 return api})();
