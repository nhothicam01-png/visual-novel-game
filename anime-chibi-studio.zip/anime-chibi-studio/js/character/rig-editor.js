ACS.rigEditor=(function(){const S=ACS.state,B=ACS.bus,$=id=>document.getElementById(id),dlg=$('rigDlg'),cv=$('rigCv'),ctx=cv.getContext('2d'),rig=ACS.rig;
 const TYPES=['Root','Head','Neck','Body','Left Arm','Right Arm','Left Leg','Right Leg','Hair'];
 const HINT={bone:'Xương: kéo trên ảnh để tạo xương (đầu→đuôi). Kéo chấm để chỉnh. Xương mới tự nối vào xương đang chọn.',region:'Vùng ảnh hưởng: chọn xương rồi kéo khung trên ảnh gốc để cắt vùng gắn vào xương. Kéo mảnh bộ phận để đặt vị trí.',pose:'Pose: kéo chấm đuôi của xương để xoay. Bật Auto key ở màn hình chính để ghi keyframe.'};
 let c=null,mode='bone',selB=null,selP=null,drag=null,vs=1;const R=()=>c.rig;
 const col=b=>`hsl(${TYPES.indexOf(b.type)*40},85%,60%)`;
 function W(b){rig.rest=mode!=='pose';const m=rig.world(c,b);rig.rest=false;return m}
 function ends(b){const m=W(b);return{head:m.transformPoint({x:0,y:0}),tail:m.transformPoint({x:b.tx-b.x,y:b.ty-b.y})}}
 function toC(e){const r=cv.getBoundingClientRect();return{x:((e.clientX-r.left)*cv.width/r.width-cv.width/2)/vs,y:((e.clientY-r.top)*cv.height/r.height-cv.height/2)/vs}}
 function hit(p,ks){const bs=R().bones;for(let i=bs.length-1;i>=0;i--){const e=ends(bs[i]);for(const k of ks)if(Math.hypot(e[k].x-p.x,e[k].y-p.y)*vs<11)return{b:bs[i],k}}return null}
 const base=()=>R().pieces[0],inP=(q,p)=>p.x>=q.x&&p.x<=q.x+q.sw&&p.y>=q.y&&p.y<=q.y+q.sh;
 function draw(){if(dlg.hidden)return;ctx.fillStyle='#2a2d38';ctx.fillRect(0,0,cv.width,cv.height);ctx.save();ctx.translate(cv.width/2,cv.height/2);ctx.scale(vs,vs);
  rig.rest=mode!=='pose';rig.draw(ctx,c);rig.rest=false;ctx.lineWidth=1.5/vs;
  R().pieces.forEach(p=>{if(p.base)return;ctx.strokeStyle=p===selP?'#ff9d2e':'rgba(110,231,216,.7)';ctx.strokeRect(p.x,p.y,p.sw,p.sh)});
  if(drag&&drag.t==='rect'){ctx.strokeStyle='#fff';ctx.strokeRect(drag.x0,drag.y0,drag.x1-drag.x0,drag.y1-drag.y0)}ctx.restore();
  R().bones.forEach(b=>{const e=ends(b),h={x:cv.width/2+e.head.x*vs,y:cv.height/2+e.head.y*vs},t={x:cv.width/2+e.tail.x*vs,y:cv.height/2+e.tail.y*vs};
   ctx.strokeStyle=col(b);ctx.lineWidth=b===selB?6:3;ctx.beginPath();ctx.moveTo(h.x,h.y);ctx.lineTo(t.x,t.y);ctx.stroke();
   ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(h.x,h.y,6,0,7);ctx.fill();ctx.fillStyle=col(b);ctx.beginPath();ctx.arc(t.x,t.y,5,0,7);ctx.fill()});
  requestAnimationFrame(draw)}
 const kids=(b,a)=>{for(let x=b,n=0;x&&n<64;x=rig.bone(c,x.parent),n++)if(x.id===a.id)return true;return false};
 function fillSel(sel,items,val){sel.innerHTML='';items.forEach(([v,l])=>{const o=document.createElement('option');o.value=v;o.textContent=l;sel.appendChild(o)});sel.value=val}
 function list(ul,items,sel,pick){ul.innerHTML='';items.forEach(it=>{const li=document.createElement('li');li.textContent=it.name+(it.type?' ('+it.type+')':'');if(it===sel)li.className='on';li.onclick=()=>pick(it);ul.appendChild(li)})}
 function ui(){const r=R();list($('rBones'),r.bones,selB,b=>{selB=b;ui()});list($('rPieces'),r.pieces,selP,p=>{selP=p;ui()});
  const nb=r.bones.map(b=>[b.id,b.name]);
  ['rName','rType','rParent'].forEach(i=>$(i).disabled=!selB);$('rBoneDel').disabled=!selB;
  if(selB){if(document.activeElement!==$('rName'))$('rName').value=selB.name;fillSel($('rType'),TYPES.map(t=>[t,t]),selB.type);
   fillSel($('rParent'),[['','(không có)'],...r.bones.filter(b=>b!==selB&&!kids(b,selB)).map(b=>[b.id,b.name])],selB.parent==null?'':selB.parent)}
  $('rPieceBone').disabled=!selP;$('rPieceDel').disabled=!selP||selP.base;if(selP)fillSel($('rPieceBone'),[['','(không có)'],...nb],selP.bone==null?'':selP.bone)}
 cv.onpointerdown=e=>{if(!c)return;cv.setPointerCapture(e.pointerId);const p=toC(e);
  if(mode==='pose'){const h=hit(p,['tail']);if(h){selB=h.b;drag={t:'pose',b:h.b};ui()}return}
  if(mode==='bone'){const h=hit(p,['tail','head']);if(h){selB=h.b;drag={t:'h',b:h.b,k:h.k};ui();return}
   const id=R().nid++,b={id,name:$('rType').value+' '+id,type:selB?$('rType').value:'Root',parent:selB?selB.id:null,x:p.x,y:p.y,tx:p.x,ty:p.y,rot:0};
   if(!selB)b.name='Root '+id;R().bones.push(b);selB=b;drag={t:'new',b};ui();return}
  const ps=R().pieces;for(let i=ps.length-1;i>0;i--)if(inP(ps[i],p)){selP=ps[i];drag=ps[i].cut?null:{t:'mv',p:ps[i],dx:ps[i].x-p.x,dy:ps[i].y-p.y};ui();return}
  if(!selB)return ACS.toast('Chọn xương trước khi cắt vùng',1);if(inP(base(),p))drag={t:'rect',x0:p.x,y0:p.y,x1:p.x,y1:p.y}};
 cv.onpointermove=e=>{if(!drag)return;const p=toC(e),d=drag;
  if(d.t==='new'){d.b.tx=p.x;d.b.ty=p.y}else if(d.t==='h'){if(d.k==='head'){d.b.x=p.x;d.b.y=p.y}else{d.b.tx=p.x;d.b.ty=p.y}}
  else if(d.t==='mv'){d.p.x=p.x+d.dx;d.p.y=p.y+d.dy}else if(d.t==='rect'){d.x1=p.x;d.y1=p.y}
  else if(d.t==='pose'){const m=rig.world(c,d.b),h=m.transformPoint({x:0,y:0}),t=m.transformPoint({x:d.b.tx-d.b.x,y:d.b.ty-d.b.y});
   d.b.rot=Math.round((d.b.rot+(Math.atan2(p.y-h.y,p.x-h.x)-Math.atan2(t.y-h.y,t.x-h.x))*180/Math.PI)*10)/10;B.emit('edit',c)}};
 cv.onpointerup=()=>{const d=drag;drag=null;if(!d)return;
  if(d.t==='new'&&Math.hypot(d.b.tx-d.b.x,d.b.ty-d.b.y)<8){R().bones=R().bones.filter(b=>b!==d.b);selB=null;ui()}
  if(d.t==='rect'){const bp=base(),x0=Math.max(bp.x,Math.min(d.x0,d.x1)),y0=Math.max(bp.y,Math.min(d.y0,d.y1)),x1=Math.min(bp.x+bp.sw,Math.max(d.x0,d.x1)),y1=Math.min(bp.y+bp.sh,Math.max(d.y0,d.y1));
   if(x1-x0>=4&&y1-y0>=4){const n=R().pieces.filter(q=>q.cut).length+1;selP={img:0,sx:Math.round(x0-bp.x),sy:Math.round(y0-bp.y),sw:Math.round(x1-x0),sh:Math.round(y1-y0),x:Math.round(x0),y:Math.round(y0),bone:selB.id,cut:true,name:'Vùng '+n+' → '+selB.name};R().pieces.push(selP);ui()}}};
 document.querySelectorAll('[name=rmode]').forEach(r=>r.onchange=()=>{mode=r.value;$('rHint').textContent=HINT[mode]});
 $('rName').oninput=e=>{selB.name=e.target.value;ui()};$('rType').onchange=e=>{selB.type=e.target.value;ui()};$('rParent').onchange=e=>{selB.parent=e.target.value===''?null:+e.target.value;ui()};
 $('rPieceBone').onchange=e=>{selP.bone=e.target.value===''?null:+e.target.value;ui()};
 $('rBoneDel').onclick=()=>{const b=selB;R().bones.forEach(x=>{if(x.parent===b.id)x.parent=b.parent});R().pieces.forEach(p=>{if(p.bone===b.id)p.bone=null});R().bones=R().bones.filter(x=>x!==b);selB=null;ui();B.emit('edit',c)};
 $('rPieceDel').onclick=()=>{R().pieces=R().pieces.filter(x=>x!==selP);selP=null;rig.gc(c);ui()};
 const mv=d=>{const ps=R().pieces,i=ps.indexOf(selP),j=i+d;if(!selP||selP.base||j<1||j>=ps.length)return;[ps[i],ps[j]]=[ps[j],ps[i]];ui()};
 $('rPieceUp').onclick=()=>mv(1);$('rPieceDn').onclick=()=>mv(-1);
 $('rReset').onclick=()=>{R().bones.forEach(b=>b.rot=0);B.emit('edit',c)};$('rClose').onclick=()=>{dlg.hidden=true;drag=null;rig.noAnim=false;B.emit('chars')};
 $('rPartBtn').onclick=()=>$('rPart').click();
 $('rPart').onchange=async e=>{for(const f of e.target.files){try{const l=await ACS.loader.load(f),r=R();r.images.push({bmp:l.bmp,blob:l.blob,url:l.url});
  selP={img:r.images.length-1,sx:0,sy:0,sw:l.bmp.width,sh:l.bmp.height,x:-l.bmp.width/2,y:-l.bmp.height/2,bone:selB?selB.id:null,cut:false,name:f.name.replace(/\.[^.]+$/,'')};r.pieces.push(selP)}catch(err){ACS.toast(err.message,1)}}
  e.target.value='';ui()};
 return{open(){c=S.selected;if(!c)return ACS.toast('Chọn một nhân vật trước',1);rig.ensure(c);mode='bone';document.querySelector('[name=rmode][value=bone]').checked=true;$('rHint').textContent=HINT.bone;
  selB=null;selP=null;vs=Math.min(1.5,(cv.height-80)/c.bmp.height,(cv.width-80)/c.bmp.width);dlg.hidden=false;rig.noAnim=true;ui();draw()}}})();
