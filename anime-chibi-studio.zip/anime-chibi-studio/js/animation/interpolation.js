ACS.interp={lerp:(a,b,t)=>a+(b-a)*t,ease:{linear:t=>t,easeIn:t=>t*t,easeOut:t=>t*(2-t),
 easeInOut:t=>t<.5?2*t*t:-1+(4-2*t)*t,
 bounce:t=>{const n=7.5625,d=2.75;if(t<1/d)return n*t*t;if(t<2/d)return n*(t-=1.5/d)*t+.75;if(t<2.5/d)return n*(t-=2.25/d)*t+.9375;return n*(t-=2.625/d)*t+.984375},
 elastic:t=>t===0||t===1?t:Math.pow(2,-10*t)*Math.sin((t*10-.75)*2*Math.PI/3)+1}};
