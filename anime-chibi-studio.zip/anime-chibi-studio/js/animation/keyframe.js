ACS.keyframe={PROPS:['x','y','scale','rotation','opacity'],
 set(o,t,props,ease){let k=o.keys.find(k=>Math.abs(k.t-t)<1e-6);if(!k){k={t,props:{},ease:'linear'};o.keys.push(k)}
  Object.assign(k.props,props);if(ease)k.ease=ease;o.keys.sort((a,b)=>a.t-b.t);return k},
 remove(o,k){o.keys=o.keys.filter(x=>x!==k)},
 snapshot(c){const p=c.props,o={x:p.x,y:p.y,scale:p.scale,rotation:p.rotation,opacity:p.opacity};if(c.rig)c.rig.bones.forEach(b=>o['b'+b.id]=b.rot);return o},
 apply(c,e){for(const n in e){if(this.PROPS.includes(n))c.props[n]=e[n];else if(c.rig){const b=c.rig.bones.find(b=>'b'+b.id===n);if(b)b.rot=e[n]}}},
 evaluate(o,t){if(!o.keys.length)return null;const out={},ns=new Set();o.keys.forEach(k=>Object.keys(k.props).forEach(n=>ns.add(n)));
  for(const p of ns){const a=o.keys.filter(k=>p in k.props);if(!a.length)continue;
   if(t<=a[0].t){out[p]=a[0].props[p];continue}const l=a[a.length-1];if(t>=l.t){out[p]=l.props[p];continue}
   const i=a.findIndex(k=>k.t>t)-1,A=a[i],B=a[i+1];out[p]=ACS.interp.lerp(A.props[p],B.props[p],ACS.interp.ease[A.ease]((t-A.t)/(B.t-A.t)))}
  return out}};
