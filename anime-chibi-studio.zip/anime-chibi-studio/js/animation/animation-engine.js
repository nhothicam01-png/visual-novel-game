ACS.anim=(function(){const api={presets:{},
 init(){ACS.presetData.forEach(p=>api.presets[p.name]=p);try{JSON.parse(localStorage.getItem('acs.presets')||'[]').forEach(p=>{p.user=true;api.presets[p.name]=p})}catch(e){}},
 save(){try{localStorage.setItem('acs.presets',JSON.stringify(Object.values(api.presets).filter(p=>p.user)))}catch(e){ACS.toast('Không lưu được preset',1)}},
 eval(p,lt){const o={};for(const n in p.tracks){const k=p.tracks[n];if(!k.length)continue;if(lt<=k[0][0]){o[n]=k[0][1];continue}const l=k[k.length-1];if(lt>=l[0]){o[n]=l[1];continue}
  const i=k.findIndex(x=>x[0]>lt)-1,a=k[i],b=k[i+1];o[n]=ACS.interp.lerp(a[1],b[1],ACS.interp.ease[a[2]||'easeInOut']((lt-a[0])/(b[0]-a[0])))}return o},
 apply(c,t){const a=c.anim=c.anim||{dx:0,dy:0,rot:0},bs=c.rig?c.rig.bones:[],act=[];a.dx=a.dy=a.rot=0;bs.forEach(b=>b.arot=0);
  for(const cl of c.clips||[]){const p=api.presets[cl.preset],end=cl.start+cl.len;if(!p||t<cl.start||t>end)continue;const f=Math.max(.001,cl.fade||0);
   let lt=(t-cl.start)*cl.speed;lt=cl.loop?lt%p.dur:Math.min(lt,p.dur);act.push({w:Math.min(1,(t-cl.start)/f,(end-t)/f),v:api.eval(p,lt)})}
  const sc=1/Math.max(1,act.reduce((s,x)=>s+x.w,0));
  for(const {w,v} of act)for(const n in v){const x=v[n]*w*sc;if(n==='dx'||n==='dy'||n==='rot')a[n]+=x;else bs.forEach(b=>{if(b.type===n)b.arot+=x})}},
 fromKeys(c,name,loop){const ks=c.keys;if(ks.length<2)throw new Error('Cần ít nhất 2 keyframe');const t0=ks[0].t,f=ks[0].props,tr={};
  const add=(n,pn,base)=>{const a=ks.filter(k=>pn in k.props).map(k=>[+(k.t-t0).toFixed(3),+(k.props[pn]-base).toFixed(2),k.ease]);if(a.length>1&&a.some(x=>Math.abs(x[1])>.01))tr[n]=a};
  add('dx','x',f.x);add('dy','y',f.y);add('rot','rotation',f.rotation);
  (c.rig?c.rig.bones:[]).forEach(b=>{const k0=ks.find(k=>('b'+b.id) in k.props);if(k0)add(b.type,'b'+b.id,k0.props['b'+b.id])});
  if(!Object.keys(tr).length)throw new Error('Keyframe chưa có chuyển động nào');
  api.presets[name]={name,dur:Math.max(.1,ks[ks.length-1].t-t0),loop:!!loop,tracks:tr,user:true};api.save()}};
 api.init();return api})();
