ACS.editor=(function(){const S=ACS.state,B=ACS.bus,cv=document.getElementById('stage'),ctx=cv.getContext('2d'),W=1280,H=720;let drag=null,safe=false;
 const ep=c=>{const a=c.anim||{dx:0,dy:0,rot:0};return{...c.props,x:c.props.x+a.dx,y:c.props.y+a.dy,rotation:c.props.rotation+a.rot}};const rad=c=>ep(c).rotation*Math.PI/180;
 function local(c,px,py){const r=rad(c),q=ep(c),dx=px-q.x,dy=py-q.y,s=q.scale;return{x:(dx*Math.cos(r)+dy*Math.sin(r))/s,y:(-dx*Math.sin(r)+dy*Math.cos(r))/s}}
 const hit=(c,p)=>{const l=local(c,p.x,p.y);return Math.abs(l.x)<=c.bmp.width/2&&Math.abs(l.y)<=c.bmp.height/2};
 function handle(c){const r=rad(c),oy=-(c.bmp.height/2*c.props.scale+32);const q=ep(c);return{x:q.x-oy*Math.sin(r),y:q.y+oy*Math.cos(r)}}
 function pt(e){const r=cv.getBoundingClientRect();return{x:(e.clientX-r.left)*W/r.width,y:(e.clientY-r.top)*H/r.height}}
 function draw(){ctx.fillStyle='#fff';ctx.fillRect(0,0,W,H);
  for(const c of S.characters){const p=ep(c);ctx.save();ctx.globalAlpha=p.opacity;ctx.translate(p.x,p.y);ctx.rotate(rad(c));
   ctx.scale(p.scale*(p.flipH?-1:1),p.scale*(p.flipV?-1:1));ACS.rig.draw(ctx,c);ctx.restore()}
  const c=S.selected;if(c){const p=ep(c),w=c.bmp.width*p.scale,h=c.bmp.height*p.scale,hd=handle(c);ctx.save();ctx.strokeStyle='#ff4fa0';ctx.lineWidth=2;
   ctx.translate(p.x,p.y);ctx.rotate(rad(c));ctx.strokeRect(-w/2,-h/2,w,h);ctx.restore();
   ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(hd.x,hd.y);ctx.stroke();ctx.beginPath();ctx.arc(hd.x,hd.y,9,0,7);ctx.fillStyle='#ff4fa0';ctx.fill()}
  if(safe){ctx.strokeStyle='rgba(0,150,255,.7)';ctx.setLineDash([8,6]);ctx.lineWidth=2;ctx.strokeRect(W*.05,H*.05,W*.9,H*.9);ctx.strokeRect(W*.1,H*.1,W*.8,H*.8);ctx.setLineDash([])}
  requestAnimationFrame(draw)}
 cv.addEventListener('pointerdown',e=>{const p=pt(e),sel=S.selected;cv.setPointerCapture(e.pointerId);
  if(sel){const h=handle(sel);if(Math.hypot(p.x-h.x,p.y-h.y)<16){drag={t:'rot'};return}}
  for(let i=S.characters.length-1;i>=0;i--){const c=S.characters[i];if(hit(c,p)){ACS.chars.select(c.id);drag={t:'mv',dx:c.props.x-p.x,dy:c.props.y-p.y};return}}
  ACS.chars.select(null)});
 cv.addEventListener('pointermove',e=>{const c=S.selected;if(!drag||!c)return;const p=pt(e);
  if(drag.t==='mv'){c.props.x=Math.round(p.x+drag.dx);c.props.y=Math.round(p.y+drag.dy)}
  else c.props.rotation=Math.round((Math.atan2(p.y-c.props.y,p.x-c.props.x)*180/Math.PI+90)*10)/10;B.emit('edit',c)});
 cv.addEventListener('pointerup',()=>drag=null);
 cv.addEventListener('wheel',e=>{const c=S.selected;if(!c)return;e.preventDefault();c.props.scale=Math.max(.01,c.props.scale*(e.deltaY<0?1.05:.95));B.emit('edit',c)},{passive:false});
 draw();return{setSafe(v){safe=v}}})();
