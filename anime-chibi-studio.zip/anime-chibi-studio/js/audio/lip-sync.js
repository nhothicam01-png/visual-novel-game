ACS.lip={
 textToVis(t){const out=[],push=v=>{if(out[out.length-1]!==v)out.push(v)},M={a:'A',e:'E',i:'I',y:'I',o:'O',u:'U',m:'M',b:'M',p:'M',f:'F',v:'F',l:'L'};
  for(const ch of t.toLowerCase().normalize('NFD').replace(/đ/g,'d').replace(/[\u0300-\u036f]/g,'').replace(/ph/g,'f')){if(M[ch])push(M[ch]);else if(/[\s.,!?;:…-]/.test(ch))push('Rest')}
  while(out[0]==='Rest')out.shift();while(out[out.length-1]==='Rest')out.pop();return out.join(' ')},
 build(s){const toks=(s.visStr||'').split(/\s+/).filter(x=>ACS.VISEMES.includes(x));s.vis=[];if(!toks.length)return;const wt=v=>v==='Rest'?.6:'MFL'.includes(v)?.5:1;
  if(s.voiced&&s.voiced.length){const sp=toks.filter(v=>v!=='Rest'),W=sp.reduce((a,v)=>a+wt(v),0)||1,L=s.voiced.reduce((a,[x,y])=>a+y-x,0);let cp=0;
   const real=x=>{for(const [a,b] of s.voiced){if(x<b-a)return a+x;x-=b-a}return s.voiced[s.voiced.length-1][1]};
   sp.forEach(v=>{s.vis.push({t:+real(cp/W*L).toFixed(3),v});cp+=wt(v)});s.voiced.forEach(([a,b])=>s.vis.push({t:b,v:'Rest'}));s.vis.sort((a,b)=>a.t-b.t)}
  else{const D=Math.max(.1,s.end-s.start),W=toks.reduce((a,v)=>a+wt(v),0);let cp=0;toks.forEach(v=>{s.vis.push({t:+(cp/W*D).toFixed(3),v});cp+=wt(v)});s.vis.push({t:D,v:'Rest'})}},
 async analyze(blob){const AC=window.AudioContext||window.webkitAudioContext,ac=new AC();
  try{const buf=await ac.decodeAudioData(await blob.arrayBuffer()),d=buf.getChannelData(0),win=Math.floor(buf.sampleRate*.02),n=Math.floor(d.length/win),rms=[];
   for(let i=0;i<n;i++){let s=0;for(let j=i*win;j<(i+1)*win;j++)s+=d[j]*d[j];rms.push(Math.sqrt(s/win))}
   const th=Math.max(.01,rms.reduce((a,b)=>Math.max(a,b),0)*.15),iv=[];let st=null;
   rms.forEach((r,i)=>{if(r>=th){if(st===null)st=i}else if(st!==null){iv.push([st*.02,i*.02]);st=null}});if(st!==null)iv.push([st*.02,n*.02]);
   const m=[];iv.forEach(x=>{const l=m[m.length-1];if(l&&x[0]-l[1]<.12)l[1]=x[1];else m.push([...x])});
   return{dur:buf.duration,voiced:m.filter(x=>x[1]-x[0]>=.06).map(x=>x.map(v=>+v.toFixed(3)))}}
  catch(e){throw new Error('Không đọc được audio (định dạng không hỗ trợ?)')}finally{ac.close()}}};
