# Anime Chibi Animation Studio

Ứng dụng web làm hoạt hình 2D (Vanilla JS, Canvas). Không cần build: mở `index.html` hoặc chạy `python3 -m http.server`.

## Giai đoạn 1 (hiện tại)
Editor + Canvas, upload ảnh (kiểm tra định dạng/dung lượng, giải phóng Object URL), kéo/xoay/zoom, Properties, Timeline với keyframe, nội suy (linear, ease in/out, bounce, elastic), phát preview.

## Giai đoạn 2–3
Rig Editor: xương (9 loại, parent, pivot), vùng ảnh hưởng (cắt thủ công ảnh đơn), thêm bộ phận PNG, pose bằng cách kéo xương, keyframe cả góc xoay xương.

## Giai đoạn 4
Animation Engine: 17 preset (Idle, Walk, Run, Jump, Sit, Stand, Lie Down, Turn L/R, Bow, Nod, Shake Head, Wave, Dance, Laugh, Cry, Attack) chạy theo loại xương, clip trên timeline (loop, tốc độ, fade/cross-fade), tạo preset từ keyframe.

## Giai đoạn 5
Face Editor (12 biểu cảm, texture mắt/miệng, lệch vị trí, miệng mở/đóng hoặc cố định), Lip Sync (A E I O U M F L Rest) tự sinh từ lời thoại tiếng Việt, căn theo đoạn có tiếng khi gắn audio, chỉnh tay.

## Giai đoạn 6
Script Studio: trình soạn thảo có số dòng, parser nhiều bước (phân loại dòng → thu thập nhân vật → nhận diện biểu cảm/động tác/camera/thời gian → chia cảnh → kiểm tra lỗi), kết quả JSON chỉnh sửa được, gán nhân vật, xuất JSON.

## Còn lại
Scene/Camera → Audio → Render WebM → Project Manager (IndexedDB), Undo/Redo.
